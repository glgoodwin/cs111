module BindexPartialEval = struct

  open FunUtils
  open ListUtils
  open Bindex

  

  let rec partialEval (Pgm(fmls,body)) = 
    (* replace this stub *)
    Pgm(fmls, (peval body (Env.make fmls)))

  and peval exp env = 
    match exp with 
      Lit i -> i
    | Var name ->
	raise (EvalError("Unbound variable: " ^ name))
    | BinApp(rater,rand1,rand2) ->
	BindexEnvInterp.binApply rator (eval rand1 env) (eval rand2 env)
    | Bind(name, defn, body) ->
	eval (subst1 (Lit (eval defn env)) name body) env

end
