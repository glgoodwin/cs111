#use "../utils/load-utils.ml"
#use "../bindex/load-bindex.ml"
#use "BindexPartialEval.ml"
#use "BindexPartialEvalTest.ml"
let testPartialEval = BindexPartialEvalTest.testPartialEval
let test = BindexPartialEvalTest.test




